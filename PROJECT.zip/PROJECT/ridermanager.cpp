#include<iostream>
#include"ridermanager.h"
#include<vector>
#include<climits>
#include"payment.h"
using namespace std;
RideManager* RideManager::instance = nullptr;  


RideManager* RideManager::getInstance() {
    if (!instance) instance = new RideManager();
    return instance;
}


void RideManager::assignRide(Rider* rider, vector<Driver*>& drivers) {
   Driver* nearstDriver=findNearestDriver(rider,drivers);
   
   if(nearstDriver){
    int distance = rand() % 10 + 1;
    double fare = Payment::calculateFare(distance);
    cout<<"Ride assigned to:"<<nearstDriver->name<<" At a Distance:"<<distance<<"km/h "<<"At a Fare of $"<<fare<<"\n";
    nearstDriver->available=false;
   }
   else{
    cout<<"no drivers available Please Try Later!..\n";
   }

}

Driver* RideManager::findNearestDriver(Rider *rider ,std::vector<Driver*>& drivers){
    Driver* nearestDriver=nullptr;
    int minDistance=INT_MAX;

    for(Driver* driver:drivers){
        if(driver->available){
            int distance=rand()%10+1;
            if(distance<minDistance){
                minDistance=distance;
                nearestDriver=driver;
            }
        }
    }
    return nearestDriver;
}
void RideManager::CompleteRide(Driver* driver){
    driver->available=true;
    cout<<driver->name<<" is available for rides now..\n";
}