
class Payment{
   
   public:
   static double calculateFare(int distance);
};