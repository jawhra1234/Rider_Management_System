#include<iostream>
#include"rider.h"
#include"driver.h"
#include<vector>
#pragma once
class RideManager {
    private:
        static RideManager* instance; 
        RideManager() {} 
    
    public:
        static RideManager* getInstance();
        void assignRide(Rider* rider,std::vector<Driver*>& drivers);
        Driver* findNearestDriver(Rider* rider, std::vector<Driver*>& drivers);
        void CompleteRide(Driver* drivers);
    };
    